"""Multi-institution primitives. Legacy academic routes remain single-tenant until audited."""
from datetime import datetime, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from bson import ObjectId
from fastapi import HTTPException
from app.database import get_database

def now_utc():
    return datetime.now(timezone.utc)

def valid_timezone(value):
    try:
        ZoneInfo(value)
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        raise HTTPException(422, detail={"code":"INVALID_TIMEZONE","message":"Zona horaria IANA inválida"})
    return value

def institution(db, identifier, active=True):
    if not isinstance(identifier,str) or not ObjectId.is_valid(identifier):
        raise HTTPException(422, detail={"code":"INVALID_INSTITUTION","message":"Institución inválida"})
    query={"_id":ObjectId(identifier)}
    if active: query["status"]="active"
    doc=db.institutions.find_one(query)
    if not doc: raise HTTPException(404, detail={"code":"INSTITUTION_NOT_FOUND","message":"Institución no disponible"})
    return doc

def public_institution(doc):
    return {"id":str(doc["_id"]),"name":doc["name"],"slug":doc["slug"],"timezone":doc["timezone"],"period_type":doc["period_type"]}

def check_platform(user):
    if user.get("role") not in ("super_admin","admin") or user.get("institution_id"):
        raise HTTPException(403,detail={"code":"FORBIDDEN","message":"Solo administración de plataforma"})

def is_institution_admin(db,user,institution_id):
    if user.get("role") in ("admin","super_admin") and not user.get("institution_id"):
        return True
    return db.role_assignments.find_one({"institution_id":institution_id,"user_id":str(user["_id"]),"role":"institution_admin","status":"active"}) is not None
