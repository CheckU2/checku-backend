"""Safe opt-in institution administration, independent of legacy academic CRUD."""
import re
from datetime import datetime, timezone
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from pymongo.errors import DuplicateKeyError
from app.database import get_database
from app.dependencies import get_current_user
from app.services.institutions import institution, public_institution, valid_timezone, check_platform, is_institution_admin, now_utc
from app.config import get_settings

router=APIRouter(tags=["Instituciones"])
def db_required():
    db=get_database()
    if db is None: raise HTTPException(503,detail={"code":"DATABASE_UNAVAILABLE","message":"Base de datos no disponible"})
    return db

@router.get('/institutions/public')
def list_public():
    db=db_required()
    return {"success":True,"data":[public_institution(x) for x in db.institutions.find({"status":"active"}).sort("name",1).limit(100)]}

@router.get('/institutions/{institution_id}/careers/public')
def public_careers(institution_id:str):
    db=db_required(); institution(db,institution_id)
    return {"success":True,"data":[{"id":str(x['_id']),"name":x.get('name',''),"code":x.get('code')} for x in db.careers.find({"institution_id":institution_id,"is_deleted":{"$ne":True}}).limit(200)]}

@router.post('/platform/institutions',status_code=201)
def create_institution(payload:dict,user=Depends(get_current_user)):
    check_platform(user); db=db_required()
    name=payload.get('name'); slug=payload.get('slug'); zone=payload.get('timezone','America/Mexico_City'); period=payload.get('period_type','quarter')
    if not isinstance(name,str) or not 3<=len(name.strip())<=150 or not isinstance(slug,str) or not re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*',slug) or len(slug)>80:
        raise HTTPException(422,detail={'code':'INVALID_INSTITUTION','message':'Nombre o identificador inválido'})
    if period not in ('quarter','semester'): raise HTTPException(422,detail={'code':'INVALID_PERIOD','message':'Periodo inválido'})
    valid_timezone(zone)
    # In the compatibility release, new institutions are staged until all academic endpoints enforce tenant isolation.
    doc={'name':name.strip(),'slug':slug,'timezone':zone,'period_type':period,'status':'staged','settings':{},'created_at':now_utc(),'updated_at':now_utc()}
    try: result=db.institutions.insert_one(doc)
    except DuplicateKeyError: raise HTTPException(409,detail={'code':'SLUG_EXISTS','message':'Identificador ocupado'})
    return {'success':True,'data':{'id':str(result.inserted_id),'status':'staged'},'message':'Institución creada en modo preparación; requiere activación tras auditoría multiinstitucional'}

@router.patch('/institutions/{institution_id}/settings')
def update_settings(institution_id:str,payload:dict,user=Depends(get_current_user)):
    db=db_required(); institution(db,institution_id,active=False)
    if not is_institution_admin(db,user,institution_id): raise HTTPException(403,detail={'code':'FORBIDDEN','message':'No autorizado'})
    changes={}
    if 'timezone' in payload: changes['timezone']=valid_timezone(payload['timezone'])
    if 'period_type' in payload:
        if payload['period_type'] not in ('quarter','semester'): raise HTTPException(422,detail={'code':'INVALID_PERIOD','message':'Periodo inválido'})
        changes['period_type']=payload['period_type']
    if not changes: raise HTTPException(422,detail={'code':'EMPTY_UPDATE','message':'Sin cambios permitidos'})
    changes['updated_at']=now_utc()
    db.institutions.update_one({'_id':ObjectId(institution_id)},{'$set':changes})
    return {'success':True,'data':{'id':institution_id,**{k:v for k,v in changes.items() if k!='updated_at'}}}

@router.post('/institutions/{institution_id}/role-assignments',status_code=201)
def assign_role(institution_id:str,payload:dict,user=Depends(get_current_user)):
    db=db_required(); institution(db,institution_id,active=False)
    if not is_institution_admin(db,user,institution_id): raise HTTPException(403,detail={'code':'FORBIDDEN','message':'No autorizado'})
    target=payload.get('user_id'); role=payload.get('role'); scope=payload.get('scope_type','institution'); scope_id=payload.get('scope_id')
    if not isinstance(target,str) or not ObjectId.is_valid(target) or role not in ('institution_admin','career_admin','teacher','tutor','student') or scope not in ('institution','career','group','class'):
        raise HTTPException(422,detail={'code':'INVALID_ASSIGNMENT','message':'Asignación inválida'})
    if scope=='institution' and scope_id is not None or scope!='institution' and (not isinstance(scope_id,str) or not ObjectId.is_valid(scope_id)):
        raise HTTPException(422,detail={'code':'INVALID_SCOPE','message':'Ámbito inválido'})
    member=db.institution_memberships.find_one({'institution_id':institution_id,'user_id':target,'status':'active'})
    if not member: raise HTTPException(409,detail={'code':'NOT_A_MEMBER','message':'El usuario no pertenece a la institución'})
    if role=='institution_admin' and (user.get('role') not in ('admin','super_admin') or user.get('institution_id')):
        raise HTTPException(403,detail={'code':'FORBIDDEN','message':'Solo plataforma puede delegar administración institucional'})
    if scope!='institution':
        coll={'career':'careers','group':'groups','class':'classes'}[scope]
        resource=db[coll].find_one({'_id':ObjectId(scope_id),'institution_id':institution_id})
        if not resource: raise HTTPException(422,detail={'code':'INVALID_SCOPE','message':'Recurso fuera de la institución'})
    query={'institution_id':institution_id,'user_id':target,'role':role,'scope_type':scope,'scope_id':scope_id}
    db.role_assignments.update_one(query,{'$set':{'status':'active','assigned_by':str(user['_id']),'assigned_at':now_utc()}},upsert=True)
    return {'success':True,'data':query}
